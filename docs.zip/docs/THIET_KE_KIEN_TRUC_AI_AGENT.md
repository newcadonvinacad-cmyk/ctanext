# ĐẶC TẢ KIẾN TRÚC & TỔ CHỨC CODE PHÂN HỆ AI AGENT
## DỰ ÁN: SIGNAGE ERP (QUẢN TRỊ DOANH NGHIỆP BIỂN QUẢNG CÁO)
**Model AI sử dụng:** `gemini-3.5-flash-lite` | **SDK:** `@google/genai` | **Nguyên tắc:** Task-oriented & Human-in-the-loop

---

## 1. Triết Lý Thiết Kế Kỹ Thuật

Phân hệ AI được thiết kế theo nguyên tắc hỗ trợ nhập liệu, không can thiệp tự động vào luồng dữ liệu chính:
1. **Human-in-the-loop (Con người kiểm soát)**: AI chỉ có nhiệm vụ bóc tách dữ liệu phi cấu trúc (tiếng nói, hình ảnh chứng từ) thành dữ liệu có cấu trúc (JSON).
2. **Cơ chế Dự thảo (Draft Form)**: Dữ liệu từ AI được điền vào form dự thảo trên giao diện. Người dùng kiểm tra, chỉnh sửa và bấm xác nhận thì dữ liệu mới được ghi vào hệ thống theo quy trình duyệt.
3. **Bảo mật phía Server**: API Key AI được lưu trữ trên môi trường Server, không gửi về phía Client.

---

## 2. Mô Hình 5 File Tiêu Chuẩn Cho Mỗi Agent

Mỗi chức năng Agent được phân bổ theo 5 tầng trách nhiệm:

```text
[Giao diện Người dùng]
       │ (1. Gửi dữ liệu thô: text / image)
       ▼
1. src/app/api/ai/[agent-name]/route.ts       ◄── CỔNG API TIẾP NHẬN & BẢO MẬT API KEY
       │ (2. Chuyển tiếp request)
       ▼
2. src/services/ai.service.ts                 ◄── TẦNG ĐIỀU PHỐI NGHIỆP VỤ
       │ (3. Lấy Prompt & Schema)
       ├──► 3. src/lib/ai/agents/[agent].ts   ◄── KHUNG PROMPT & TỪ KHÓA CHUYÊN MÔN
       ├──► 4. src/types/ai.types.ts          ◄── HỢP ĐỒNG DỮ LIỆU (INTERFACE JSON ĐẦU RA)
       │ (4. Gọi Driver xử lý)
       ▼
5. src/lib/ai/gemini.ts                       ◄── DRIVER HẠ TẦNG (Gọi SDK gemini-3.5-flash-lite)
       │ (5. Gọi API)
       ▼
[Google Gemini 3.5 Flash-Lite API]
```

---

## 3. Trách Nhiệm Chi Tiết Từng File

### 📄 File 1: `src/types/ai.types.ts` (Hợp Đồng Dữ Liệu - DTO)
* Định nghĩa cấu trúc JSON mà Agent cần trả về.
* Chỉ chứa định nghĩa TypeScript (`interface`, `type`), không chứa code thực thi.

### 📄 File 2: `src/lib/ai/agents/[agent-name].agent.ts` (Định Nghĩa Prompt Của Agent)
* Chứa System Prompt, vai trò và quy tắc định dạng kết quả của từng Agent.
* Được thiết kế tách rời: Khi cần tinh chỉnh câu lệnh hoặc bổ sung từ khóa ngành, chỉ sửa tại file này.

### 📄 File 3: `src/lib/ai/gemini.ts` (Driver Hạ Tầng AI)
* Khởi tạo kết nối SDK `@google/genai` với model `gemini-3.5-flash-lite`.
* Cung cấp các hàm kỹ thuật: gửi prompt, nhận phản hồi, parse chuỗi JSON an toàn.

### 📄 File 4: `src/services/ai.service.ts` (Tầng Điều Phối Nghiệp Vụ)
* Nhận yêu cầu từ tầng API, kết hợp dữ liệu bối cảnh cần thiết, gọi Driver AI và kiểm tra tính hợp lệ của dữ liệu trước khi trả về.

### 📄 File 5: `src/app/api/ai/[agent-name]/route.ts` (Cổng API Route Handler)
* Tiếp nhận HTTP Request từ giao diện client.
* Xác thực quyền truy cập và chuyển tiếp tới `ai.service.ts`.
* Đảm bảo không để lộ API Key ra trình duyệt.

---

## 4. Định Hướng Các Agent Dự Kiến Trong Hệ Thống

*(Nội dung chi tiết từng trường dữ liệu và prompt cụ thể sẽ được cập nhật sau khi có kết quả khảo sát biểu mẫu thực tế từ khách hàng)*

```text
src/lib/ai/agents/
├── speech-report.agent.ts      # Hỗ trợ bóc tách báo cáo từ giọng nói / ghi chú nhanh
├── document-ocr.agent.ts       # Hỗ trợ bóc tách hóa đơn / chứng từ mua hàng
└── evaluation-draft.agent.ts   # Hỗ trợ dự thảo đánh giá định kỳ
```

1. **Agent Bóc Tách Giọng Nói (`speech-report.agent.ts`)**:
   * Đầu vào: Chuỗi văn bản giọng nói.
   * Đầu ra: Dữ liệu JSON điền sẵn vào biểu mẫu báo cáo tiến độ/nhật trình để người dùng kiểm tra trước khi gửi.

2. **Agent Bóc Tách Chứng Từ Mua Hàng (`document-ocr.agent.ts`)**:
   * Đầu vào: Hình ảnh chụp hóa đơn / chứng từ mua hàng.
   * Đầu ra: Dữ liệu JSON hỗ trợ tạo nhanh **Phiếu mua hàng dự thảo**, từ đó chuyển tiếp sang bước lập **Đề xuất nhập kho** và đưa vào quy trình chờ duyệt.

3. **Agent Dự Thảo Đánh Giá (`evaluation-draft.agent.ts`)**:
   * Đầu vào: Dữ liệu số liệu tổng hợp công việc và chấm công.
   * Đầu ra: Bản dự thảo gợi ý đánh giá định kỳ để cấp quản lý tham khảo và xem xét.

---

## 5. Luồng Dữ Liệu Kỹ Thuật Tổng Quát

```text
[Người dùng thao tác: Chụp ảnh / Ghi âm]
       │
       ▼
[Giao diện gửi Request lên API Route] (/api/ai/...)
       │
       ▼
[Service tiếp nhận & gọi Gemini Driver]
       │
       ▼
[Gemini 3.5 Flash-Lite xử lý & trả về JSON]
       │
       ▼
[Giao diện hiển thị Form Dự Thảo (Draft)]
       │
       ▼
[Người dùng kiểm tra, chỉnh sửa & bấm Xác nhận] ──► [Lưu chính thức vào Supabase]
```

---

## 6. Lợi Điểm Về Mặt Kiến Trúc

* **Mô-đun hóa cao**: Từng Agent là một đơn vị độc lập, không làm ảnh hưởng đến các phần khác của hệ thống.
* **Dễ dàng hiệu chỉnh**: Khi khách hàng cung cấp mẫu biểu và quy trình thực tế, chỉ cần cập nhật Schema trong `types/` và Prompt trong `agents/`.
* **An toàn dữ liệu**: Dữ liệu luôn đi qua bước kiểm duyệt của người dùng trước khi ghi vào Database.
